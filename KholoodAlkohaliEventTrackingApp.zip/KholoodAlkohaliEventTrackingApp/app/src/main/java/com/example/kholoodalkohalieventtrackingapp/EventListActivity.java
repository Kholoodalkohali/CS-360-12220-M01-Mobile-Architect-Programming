package com.example.kholoodalkohalieventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class EventListActivity extends AppCompatActivity {

    private GridView eventGrid;
    private Button addEventButton;
    private EventDatabaseHelper dbHelper;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        eventGrid = findViewById(R.id.eventGrid);
        addEventButton = findViewById(R.id.addEventButton);
        dbHelper = new EventDatabaseHelper(this);

        loadEvents(); // Load saved events

        // Add new event button
        addEventButton.setOnClickListener(view -> {
            startActivity(new Intent(EventListActivity.this, AddEditEventActivity.class));
        });
    }

    private void loadEvents() {
        ArrayList<String> events = dbHelper.getAllEvents();

        if (events.isEmpty()) {
            Toast.makeText(this, "No events found. Add some!", Toast.LENGTH_SHORT).show();
        }

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, events);
        eventGrid.setAdapter(adapter);
    }
}

