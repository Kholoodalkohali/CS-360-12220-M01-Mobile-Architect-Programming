package com.example.kholoodalkohalieventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddEditEventActivity extends AppCompatActivity {

    private EditText eventName, eventDate, eventTime, eventDescription;
    private Button saveEventButton;
    private EventDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_event);

        eventName = findViewById(R.id.eventName);
        eventDate = findViewById(R.id.eventDate);
        eventTime = findViewById(R.id.eventTime);
        eventDescription = findViewById(R.id.eventDescription);
        saveEventButton = findViewById(R.id.saveEventButton);

        dbHelper = new EventDatabaseHelper(this); // Initialize the database

        saveEventButton.setOnClickListener(view -> {
            String name = eventName.getText().toString().trim();
            String date = eventDate.getText().toString().trim();
            String time = eventTime.getText().toString().trim();
            String description = eventDescription.getText().toString().trim();

            if (name.isEmpty() || date.isEmpty() || time.isEmpty() || description.isEmpty()) {
                Toast.makeText(AddEditEventActivity.this, "Fill all fields", Toast.LENGTH_SHORT).show();
            } else {
                dbHelper.addEvent(name, date, time, description);
                Toast.makeText(AddEditEventActivity.this, "Event Saved!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(AddEditEventActivity.this, EventListActivity.class));
            }
        });
    }
}